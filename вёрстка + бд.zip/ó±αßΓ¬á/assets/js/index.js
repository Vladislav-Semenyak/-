let elements = document.getElementsByClassName("product");
for (let i = 0; i < elements.length; i += 1) {
    elements[i].addEventListener("click", function(){
        document.getElementById("my_modal").classList.add("open")
    })
}

document.getElementById("closeModal_btn").addEventListener("click", function(){ 
    document.getElementById("my_modal").classList.remove("open")
})
document.getElementById("auth_openup").addEventListener("click", function(){ 
    document.getElementById("my_modalsa").classList.add("open")
})
