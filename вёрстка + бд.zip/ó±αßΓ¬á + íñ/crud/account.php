<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/style_account.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat&display=swap" rel="stylesheet"> 
    <title>Account</title>
</head>
<style>body{
    margin: 0;
    background-image: url("https://catherineasquithgallery.com/uploads/posts/2021-02/1612237403_65-p-fioletovie-foni-profilya-steam-78.jpg");
    font-family: 'Montserrat', sans-serif;

    font-size: 15px;
    line-height: 1.6;
    color: #333;
}
h1, h2, h3, h4, h5, h6{
    margin: 0;
}
*,
*:before,
*:after{
    box-sizing: border-box;
}

.container{
    width: 100%;
    max-width: 1180px;
    margin: 0 auto;
}
/*header */
.header{
    width: 100%;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
}
.header_inner{
    display: flex;
    justify-content: space-between;
}
.nav{
    font-size: 24px;
    text-transform: uppercase;
    padding-top: 40px;
}
.nav_link{
    display: inline-block;
    vertical-align: top;
    margin: 0 20px;
    color: white;
    text-decoration: none;
    transition: color 0.2s linear;
}
.nav_link:hover{
    color: purple;
}

/*account*/
.account{
    width: 100%;
    position: absolute;
    top: 230px;
    left: 0;
    right: 0;
    padding-top: 15px;
    
}
.account_wrapper{
    display: flex;
    flex-direction: column;
    flex-wrap: wrap;
    justify-content: space-between;
    
}
.account_naming{
    font-size: 32px;
    font-weight: bold;
    color: white;
    padding-top: 10px;
}
.name{
    width: 347px;
    height: 42px;
    border-radius: 15px;
    border: 1px solid #FFF;
    background: #242424;
    padding-top: 15px;
    margin-top: 15px;
}
.number{
    width: 347px;
    height: 42px;
    border-radius: 15px;
    border: 1px solid #FFF;
    background: #242424;
    padding-top: 15px;
    margin-top: 15px;
}
.mail{
    width: 347px;
    height: 42px;
    border-radius: 15px;
    border: 1px solid #FFF;
    background: #242424;
    padding-top: 15px;
    margin-top: 15px;    
}

.personal_text{
    color: #FFF;  
    font-size: 20px;
    font-style: normal;
    font-weight: 400;
    line-height: normal;
    margin-top: 15px;
}


</style>

<body>
    <header class="header">
        <div class="container">
            <div class="header_inner">
                <a class="logo" href="index.php"><img src="assets/logo.png"  width="150px" height="150px" alt=""></a>
                <nav class="nav">
                    <a class="nav_link" href="#">Гарантии</a>
                    <a class="nav_link" href="#">Отзывы</a>
                    <a class="nav_link" href="#">Личный кабинет</a>
                    
                </nav>
            </div>
        </div>
    </header> 
    <div class="account">
            <div class="container">
            <div class="account_naming">Личный кабинет</div>
            <div class="account_naming">Персональные данные</div>
            <div class="account_wrapper">
                <div class="personal_text">Имя</div>
                <div class="name"></div>
                <div class="personal_text">Номер телефона</div>
                <div class="number"></div>
                <div class="personal_text">Почта</div>
                <div class="mail"></div>
                
            </div>
        </div>
    </div>
    
  
</body>
</html>
