<?php



global $connect;
require 'config/connect.php';

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Products</title>
    
</head>
<style>
   body{
    margin: 0;
    background-image:url("https://catherineasquithgallery.com/uploads/posts/2021-02/1612237403_65-p-fioletovie-foni-profilya-steam-78.jpg");
    font-family: 'Montserrat', sans-serif;

    font-size: 15px;
    line-height: 1.6;
    color: #333;
}
h1, h2, h3, h4, h5, h6{
    margin: 0;
}
*,
*:before,
*:after{
    box-sizing: border-box;
}

.container{
    width: 100%;
    max-width: 1250px;
    margin: 0 auto;
}
/*header */
.header{
    width: 100%;
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
}
.header_inner{
    display: flex;
    justify-content: space-between;
}
.nav{
    font-size: 24px;
    text-transform: uppercase;
    padding-top: 40px;
}
.nav_link{
    display: inline-block;
    vertical-align: top;
    margin: 0 20px;
    color: white;
    text-decoration: none;
    transition: color 0.2s linear;
}
.nav_link:hover{
    color: purple;
}

/*menu*/
.menu{ 
    width: 100%;
    position: absolute;
    top: 250px;
    left: 0;
    right: 0;
    
}
.menu_inner{
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    width: 100%;
    
    background-color: purple;
    border-radius: 20px;
    
}
.nav_menu{
    font-size: 24px;
    text-transform: uppercase;  
    padding-top: 10px;
    margin: 1% 25px;
   
}
.nav_menu_link{
    display: inline-block;
    vertical-align: top;
    color: white;
    text-decoration: none; 
    margin-right: 3%;
    transition: color 0.2s linear;
    
    
}
.nav_menu_link:hover{
    color: purple;
}
#last_elem{
    padding-left: 200px;
}

/*offers*/
.offers{
    width: 100%;
    position: absolute;
    top: 250px;
    left: 0;
    right: 0;
}
.popular_products{
    font-size: 50px;
    font-weight: bold;
    color: white;
}
.product{
    width: 15%;
    margin-bottom: 10px;
    height: 250px;
    box-sizing: border-box;    
    transition: border 0.2s linear;
    border-radius: 1px;
    border: 3px solid purple;
    
    
}
.product:hover{
    border: 3px solid purple;

 
}
.product_wrapper{
    display: flex;
    
    flex-wrap: wrap;
    justify-content: space-between;
  
}
.product_pic{
    padding-top: 15px;
    margin: 0 auto;
    display: block;
}
.product_naming{
    font-size: 24px;
    padding-left: 10px;
    color: white;
}
.product_description{
    font-size: 14px;
    padding-top: 10px;
    padding-left: 10px;
    color: white; 
    text-align: left;
}


/*footer*/
.footer{
    width: 100%;
    position: absolute;
    top: 1000px;
    left: 0;
    right: 0;  
    
    
}
.footer_wrapper{
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: space-between;
    background-color: #E5BC29;
}
.product_info{
    width: 218px;
    height: 301px;
    border-radius: 25px;
    background: #659E39;
    margin-left: 5px;
}


.trademark{
    color: #000;
    font-size: 32px;
    font-style: normal;
    font-weight: 500;
    line-height: normal;
    padding-top: 15px;
    padding-left: 320px;
}


/*modal*/
.modal{
    position: fixed;
    left: 0;
    top: 0;
    width: 100%;
    height: 100vh;
    z-index: 1000;
    background-color: rgba(0, 0, 0, .3);
    display: grid;
    align-items: center;
    justify-content: center;
    overflow-y: auto;
    visibility: hidden;
    opacity: 0;
    transition: opacity .4s, visibility .4s;
}
.modal.open{
    visibility: visible;
    opacity: 1;
}


.modal_window{
    max-width: 1550px;
    padding: 45px;
    z-index: 1;
    background-color: #242424;
    margin: 30px 15px;
    border-radius: 35px;
    transform: scale(0);
    transition: transform .8s;
}
.modal.open .modal_window{
    transform: scale(1);
}
.wrapper_full{
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: space-between;
}
.wrapper_description{
    display: flex;
    flex-direction: column;
    flex-wrap: wrap;
    
}
.modal_name{
    color: #FFF;
    
    
    font-size: 24px;
    font-style: normal;
    font-weight: 500;
    line-height: normal;
}
.modal_description{
    color: #FFF;

    
    font-size: 16px;
    font-style: normal;
    font-weight: 500;
    line-height: normal;
    padding-top: 15px;
}

.wrapper_button{
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: space-between; 
}

.wrapper_button_second{
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: space-between; 
}
.wrapper_topping{
    display: flex;
    flex-direction: row;
    flex-wrap: wrap;
    justify-content: space-between; 
}



.modal_topping_name{
    color: #FFF;

    
    font-size: 16px;
    font-style: normal;
    font-weight: 500;
    line-height: normal;
}
.modal_topping_price{
    color: #FFF;

    
    font-size: 20px;
    font-style: normal;
    font-weight: 500;
    line-height: normal;
}
.topping_h{
    color: #FFF;

    
    font-size: 20px;
    font-style: normal;
    font-weight: 500;
    line-height: normal;
    margin-top: 25px;
    margin-bottom: 15px;
}
.wrapper_button_second_small{
    display: grid;
    align-items: center;
    justify-content: center;
}
.buy{
    width: 544px;
    height: 83px;
    color: #fff;
    border-radius: 25px;
    padding: 10px 25px;
    font-family: 'Lato', sans-serif;
    font-weight: 500;
    
    cursor: pointer;
    transition: all 0.3s ease;
    position: relative;
    display: inline-block;
    
    outline: none;
    background: purple;
    
    border: none;
    margin-top: 25px;
    color: #FFF;

    
    font-size: 24px;
    font-style: normal;
    font-weight: 500;
    line-height: normal;
}
.buy:hover{
    background: purple;
}
.modal_image{
    max-height: 300px;
}
.closeModal {
	position: absolute;
	top: 30px;
	right: 20px;
	width: 24px;
	height: 24px;
	opacity: 0.2;
	cursor: pointer;
    transition: opacity ease 0.5s;

	&:hover {
		opacity: 1;
	}
}

.closeModal::before,
.closeModal::after {
	content: '';
	position: absolute;
	top: 10px;
	display: block;
	width: 24px;
	height: 3px;
	background: #fff;
}

.closeModal::before {
	transform: rotate(45deg);
}

.closeModal::after {
	transform: rotate(-45deg);
}
.wrapper_auth{
    display: flex;
    flex-direction: column;
    flex-wrap: wrap;
    justify-content: space-between;
}

</style>
<body>
<header class="header">
        <div class="container">
            <div class="header_inner">
                <div class="logo"><img src="assets/logo.png"  width="150px" height="150px" alt=""></div>
                <nav class="nav">
                    <a class="nav_link" href="#">Гарантии</a>
                    <a class="nav_link" href="#">Отзывы</a>
                    <a class="nav_link" href="#" id="auth_openup">Добавить товар</a>
                    <a class="nav_link" href="account.php">Личный кабинет</a>

                </nav>
            </div>
        </div>
    </header>



<div class="offers">
    <div class="container">
        <div class="popular_products">Товары</div>
        <div class="product_wrapper">
            <?php



            $products = mysqli_query($connect, "SELECT * FROM `products`");



            $products = mysqli_fetch_all($products);



            foreach ($products as $product) {
            ?>
            <div class="product" id="modal">
                <img src="assets/logo.png" class="product_pic" width="150px" height = "150px" alt="">
                <div class="product_naming"><?= $product[1] ?></div>
                <div class="product_description"><?= $product[3] ?>
                </div>
                <div class="redact_stuff">
                    <a style="color: white; text-decoration: none;" href="update.php?id=<?= $product[0] ?>">Обновить информацию</a>
                    <a style="color: white; text-decoration: none; padding-left: 35px;" href="vendor/delete.php?id=<?= $product[0] ?>">Удалить</a>
                </div>
            </div>
                <?php
            }
            ?>

        </div>
    </div>
</div>
<?php



$products = mysqli_query($connect, "SELECT * FROM `products`");



$products = mysqli_fetch_all($products);



foreach ($products as $product) {
?>
<div class="modal" id="my_modal">
        <div class="modal_window">
            <div class="closeModal" id="closeModal_btn"></div>
            <div class="wrapper_full">
                <div class="modal_image"><img src="assets/logo.png" width="150px" height="150px" walt=""></div>
                <div class="wrapper_description">
                    <div class="modal_name"><?= $product[1] ?></div>
                    <div class="modal_description"><?= $product[3] ?></div>
                    </div>
                    </div>
                    <div class="wrapper_button_second_small"><button class="buy">Купить за <?= $product[2] ?> ₽</button></div>
                </div>
            </div>
        </div>
    </div>
<?php
    }
    ?>

<div class="modal" id="my_modalsa">
    <div class="modal_window">
        <div class="closeModal" id="auth_close_btn"></div>


        <form action="vendor/create.php" method="post">
            <p style="color: white">Название товара</p>
            <input type="text" name="title">
            <p style="color: white">Описание</p>
            <textarea name="description"></textarea>
            <p style="color: white">Цена</p>
            <input type="number" name="price"> <br> <br>
            <button type="submit">Добавить товар

        </form>

    </div>
</div>

        

<script src="assets/js/index.js?<?=rand()?>" type="text/javascript"></script>
</body>
<div class="footer">
            <div class="trademark">SteamKEY © 2023
                Все права защищены</div>

        </div>


    </div>
</html>
